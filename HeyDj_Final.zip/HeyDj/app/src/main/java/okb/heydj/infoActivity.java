package okb.heydj;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class infoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        TextView version = (TextView) findViewById(R.id.txtVersion);



/*
        double versionNo = 1;
        PackageInfo pInfo = null;
        try{
            pInfo = getPackageManager().getPackageInfo("okb.heydj", PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            pInfo = null;
        }
        if(pInfo != null) {
            versionNo = pInfo.versionCode;
            version.setText(Double.toString(versionNo));


        }*/


        Button dodo = (Button)findViewById(R.id.btn_dodo);
        dodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(infoActivity.this, "Doirian Larmache the GAME",
                        Toast.LENGTH_SHORT).show();
            }
        });





    }
}
