// lIBRARY
#include "mbed.h"
#include "AUDIO_DISCO_F746NG.h"
#include "SDRAM_DISCO_F746NG.h"
#include "math.h"
 

// INITIALISATION DES FONCTION ET OBJETS

// Initialisation fonction BLE 
void Init_BLE();

// Initialisation liaison serie BLE
Serial Bluetooth(D1, D0);

// Initialisation objet audio 
AUDIO_DISCO_F746NG audio;

// Debug
//Serial pc(USBTX, USBRX);

// Buffer de sortie de l'audio, stocker dans une carte SD 
SDRAM_DISCO_F746NG sdram;


// DEFINITON DES TAILLE DE BUFFER
#define AUDIO_BLOCK_SIZE   ((uint64_t)2)
#define BUFFER             SDRAM_DEVICE_ADDR
#define AUDIO_BUFFER_OUT   (SDRAM_DEVICE_ADDR + AUDIO_BLOCK_SIZE)     

// FOCNTION MAIN
int main()
{
    // Debug
    //pc.baud(9600);
    
    //INITIALISATION DES VARIABLES 
    
    // Coefficient des bote prennant comme valeur 0 ou 1. Des double sont utiliser a cause de certaine fonction utiliser dans programme (sin)
    double coefDo   =   0; 
    double coefRe   =   0; 
    double coefMi   =   0; 
    double coefFa   =   0; 
    double coefSol  =   0; 
    double coefLa   =   0;
    double coefSi   =   0; 
    double coefDo2  =   0; 
    double coefDoRe =   0; 
    double coefReMi =   0; 
    double coefFaSol =  0; 
    double coefSolLa =  0; 
    double coefLaSi  =  0;
    char ncoef = 0;
    
    // Variable récupérant la trame bluetooth. Les octets des trame sont récupérer un par un
    char octet = 0;
    
    // Variable tampon pour isoler les coefficients
    char msg1 = 0;
    char msg2 = 0;
    
    // Constante du programme (initialiser en double pour la fonction sin utiliser dans le programme)
    double PI   = 3.14159265;
    double i    = 3000;
    double a    = 0.00033333333;
    
    // Variable de sortie envoyer au buffer de sortie 
    double s;
    
    // Variable copy de s 
    double st;
    
    // Variable boucle for 
    double t;
    
    // Variable des sinusoidal 
    double Do = 0; 
    double Re = 0;
    double Mi = 0;
    double Fa = 0;
    double Sol = 0;
    double La = 0;
    double Si = 0 ;
    double Do2 = 0;
    double DoRe = 0;
    double ReMi = 0;
    double FaSol = 0;
    double SolLa = 0;
    double LaSi = 0;
    
    // Initialisation du buffer SDRAM
    memset((uint16_t*)AUDIO_BUFFER_OUT, 0, AUDIO_BLOCK_SIZE);


    // Commence l'envoie des valeur du buffer sur port jack STM32
    audio.OUT_SetAudioFrameSlot(CODEC_AUDIOFRAME_SLOT_02);
    audio.OUT_Play((uint16_t*)AUDIO_BUFFER_OUT, AUDIO_BLOCK_SIZE);
    
    // Parramétrage BLE 
    Init_BLE();
    
    // Boucle infinie 
    while (1) {
            
            // Si tram bluetooth reçu
            if(Bluetooth.readable()) {
                
                // Reception d'une tram dans un octet 
                octet = Bluetooth.getc();
                
                // Debug
                //pc.printf("\n\r octet1 : %x   octet2 : %x",octet1,octet2);
                
                // Si tram correspond à octet commande touche premier octet 
                if ( (octet&0x80) == 0x00) {
                    msg1 = octet;
                    
                    // Masque afin de séparer les bit de l'octet. chaque bits correspond a une touche 
                    coefDo = msg1 & 0x01;
                    coefRe = (msg1 & 0x02) >> 1;
                    coefMi = (msg1 & 0x04) >> 2;
                    coefFa = (msg1 & 0x08) >> 3;
                    coefSol = (msg1 & 0x10) >> 4;
                    coefLa = (msg1 & 0x20) >> 5;
                    coefSi = (msg1 & 0x40) >> 6;
                } 
                
                // Si tram correspond à octet commande touche du deuxiéme octet 
                else if ( (octet&0x80) == 0x80) {
                    
                    msg2 = octet;
                    
                    // Masque afin de séparer les bit de l'octet. chaque bits correspond a une touche                                          
                    coefDoRe = msg2 & 0x01;
                    coefReMi = (msg2 & 0x02) >> 1;
                    coefFaSol = (msg2 & 0x04) >> 2;
                    coefSolLa = (msg2 & 0x08) >> 3;
                    coefLaSi = (msg2 & 0x10) >> 4;
                    coefDo2 = (msg2 & 0x20) >> 5; 
                }
                // Debug
                //pc.printf("\n\r msg1 : %x   msg2 : %x",msg1,msg2);               
            }
            
            // Equation correspondant à chaque touche du premiére octet   
            Do  = 2*PI*36*a*coefDo*t*2;
            Re  = 2*PI*40.5*a*coefRe*t*2;
            Mi  = 2*PI*45.4*a*coefMi*t*2;
            Fa  = 2*PI*50*a*coefFa*t*2;
            Sol = 2*PI*55.05*a*coefSol*t*2;
            La  = 2*PI*61.2*a*coefLa*t*2;
            Si  = 2*PI*66*a*coefSi*t*2;
            
            // Equation correspondent à chaque touche second octet 
            DoRe  = 2*PI*38.25*a*coefDoRe*t*2;
            ReMi  = 2*PI*43.05*a*coefReMi*t*2;
            FaSol  = 2*PI*52.5*a*coefFaSol*t*2;
            SolLa  = 2*PI*57.5*a*coefSolLa*t*2;
            LaSi  = 2*PI*64*a*coefLaSi*t*2;
            Do2  = 2*PI*72*a*coefDo2*t*2;    
            
            // Adition de l'emsemble des coef afin de déternimer le nombre de touche apuyer simultanément  
            ncoef = coefDo + coefRe + coefMi + coefFa + coefSol + coefLa + coefSi + coefDo2 + coefDoRe + coefReMi + coefFaSol + coefSolLa + coefLaSi; 
            
            // Adition des différentes sinusoidales des touche premiére octet (pour les accord de notes)     
            s  = sin(Do); 
            s  += sin(Re);
            s  += sin(Mi);
            s  += sin(Fa);
            s  += sin(Sol);
            s  += sin(La);
            s  += sin(Si);
            s  += sin(Do2);
            
            // Adition des différentes sinusoidales des touche second octet (pour les accord de notes)
            s  += sin(DoRe);
            s  += sin(ReMi);
            s  += sin(FaSol);
            s  += sin(SolLa);
            s  += sin(LaSi);
            
            // Aplication d'une amplification du signal
            s *= 5; 
            
            // division par le nombre de note jouer afin de limiter l'amplitude du signal 
            s /= ncoef;
            
            // Transmition de la variable s dans le buffer SDRAM     
            memset((uint16_t*)BUFFER, s, AUDIO_BLOCK_SIZE);
            
            // Transmition du buffer sur la sortie audio
            memcpy((uint16_t *)(AUDIO_BUFFER_OUT), (uint16_t *)(BUFFER), AUDIO_BLOCK_SIZE);   
            
            // Si vrai, reprant le trasage du signal depuis le point 0
            if (s==0 && st<0 && t>i){
                t=0;
            }                   
            t++;
            
            // Copie de s dans st pour porchaine boucle 
            st = s;             
    }
}

// Fonction d'initialiation du code 
void Init_BLE()
{
    Bluetooth.baud(115200);   
}
